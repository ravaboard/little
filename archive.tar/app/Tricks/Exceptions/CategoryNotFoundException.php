<?php

namespace Tricks\Exceptions;

class CategoryNotFoundException extends AbstractNotFoundException
{

}
