<?php

return array(
    'default' => 'sync'
);
