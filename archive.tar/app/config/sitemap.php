<?php

return array(

    'tricks' => array(
        'priority' => '0.9',
        'freq'     => 'weekly',
        'lastMod'  => 'created_at',
    ),

    'tags' => array(
        'priority' => '0.9',
        'freq'     => 'daily',
        'lastMod'  => 'created_at',
    ),

    'categories' => array(
        'priority' => '0.9',
        'freq'     => 'daily',
        'lastMod'  => 'created_at',
    ),

);
