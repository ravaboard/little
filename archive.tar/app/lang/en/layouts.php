<?php 

return array(
	'meta_description' => 'Laravel tricks is a website that aggregates useful tips and tricks for Laravel PHP framework',
	'meta_author' => 'Stidges, @stidges and Maks Surguy, @msurguy',
	'site_title' => 'Laravel-Tricks.com',
    
);


