<?php 

return array(
	'reset_password' => 'Reset password',
	'resetting_password' => 'Resetting password',
	'mail_has_been_sent' => 'An e-mail with the password reset link has been sent.',
	'email' => 'Email',
	'email_reset_placeholder' => 'Email',
	'new_password' => 'New Password',
	'confirm_password' => 'Confirm New Password',
	'reset' => 'Reset password',
	'remember_password' => 'Remembered password? Login',
	'invalid_password_or_mail' => 'The password reset token or email is invalid',
	'resetting_password' => 'Resetting password',
	'email_placeholder' => 'E-mail to send password reminder...',
    
);

