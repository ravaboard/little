<?php 

return array(
	'search_results_for' => 'Search results for ":term"',
	'please_provide_search_term' => 'Please provide a search term',
    
);

