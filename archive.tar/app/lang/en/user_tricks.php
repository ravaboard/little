<?php 

return array(
	'trick_update' => 'Trick has been updated',
	'trick_deleted' => 'Trick has been deleted',
	'trick_does_not_belong_to_you' => 'This trick doesn\'t belong to you',
    
);