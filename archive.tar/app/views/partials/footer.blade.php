<div id="footer">
  <div class="container">
    <p class="text-muted credit">{{ trans('partials.credits') }} | <a href="{{ url('about') }}">{{ trans('partials.about') }}</a>
    <span class="pull-right">{{ trans('partials.footer_links') }}</span>
    </p>

  </div>
</div>
